import java.io.IOException;



import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/deleteurl")
public class DeleteServlet extends HttpServlet {

	private final static String query ="delete from user where id=?";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//get PrinterWriter
		PrintWriter pw = res.getWriter();
		//set content type
		res.setContentType("text/html");
		int id = Integer.parseInt(req.getParameter("id"));
		//load the jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//establish JDBC connection
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement","root","123456789");){
			PreparedStatement ps = con.prepareStatement(query);{
				ps.setInt(1, id);
				
				
				int count = ps.executeUpdate();
				if(count==1) {
					pw.println("<h2> Successfully Deleted Record</h2>");
					pw.println("<a href='showdata'><button class='btn btn-outline-success'>show users</button></a>");	
					 
				}else {
					pw.println("<h2> Unsuccessful Deletion</h2>");
					
					pw.println("<a href='home.html'><button class='btn btn-outline-success'>Home</button></a>");	
				}
				}
				
			
		} catch (SQLException se) {
			pw.println("<h2>"+se.getMessage()+"</h2>");
			se.printStackTrace();		
			}catch(Exception e) {
				e.printStackTrace();
			}
		pw.println("<a href='home.html'<<button class='btn btn-outline-success'>Home</button></a>");
		
		pw.close();
}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}

