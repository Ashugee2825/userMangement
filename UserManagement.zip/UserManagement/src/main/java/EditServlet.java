import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/editurl")
public class EditServlet extends HttpServlet {

	private final static String query ="select name,email,mobile,dob,city,gender from user where id =?";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//get PrinterWriter
		PrintWriter pw = res.getWriter();
		//set content type
		res.setContentType("text/html");
		
		//get the id
		int id = Integer.parseInt(req.getParameter("id"));
		 boolean success = "true".equals(req.getParameter("success"));
// Include Bootstrap CDN and JavaScript
	    pw.println("<!DOCTYPE html>");
	    pw.println("<html>");
	    pw.println("<head>");
	    pw.println("<meta charset='UTF-8'>");
	    pw.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
	    pw.println("<title>Edit User</title>");
	    pw.println("<link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css'>");
	    pw.println("<script src='https://code.jquery.com/jquery-3.5.1.slim.min.js'></script>");
	    pw.println("<script src='https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js'></script>");
	    pw.println("<script src='https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js'></script>");
	    pw.println("<script>");
	    pw.println("function confirmEdit() {");
	    pw.println("    return confirm('Are you sure you want to save the changes?');");
	    pw.println("}");
	    pw.println("</script>");
	    pw.println("</head>");
	    pw.println("<body>");

	    // Navbar
	    pw.println("<nav class='navbar navbar-expand-lg navbar-light bg-light'>");
	    pw.println("  <a class='navbar-brand' href='home.html'>User Management</a>");
	    pw.println("  <button class='navbar-toggler' type='button' data-toggle='collapse' data-target='#navbarNav' aria-controls='navbarNav' aria-expanded='false' aria-label='Toggle navigation'>");
	    pw.println("    <span class='navbar-toggler-icon'></span>");
	    pw.println("  </button>");
	    pw.println("  <div class='collapse navbar-collapse' id='navbarNav'>");
	    pw.println("    <ul class='navbar-nav'>");
	    pw.println("      <li class='nav-item'>");
	    pw.println("        <a class='nav-link' href='home.html'>Home</a>");
	    pw.println("      </li>");
	    pw.println("      <li class='nav-item'>");
	    pw.println("        <a class='nav-link' href='showdata'>Show Users</a>");
	    pw.println("      </li>");
	    pw.println("    </ul>");
	    pw.println("  </div>");
	    pw.println("</nav>");
		pw.println("<link rel='stylesheet' href ='css/bootstrap.css'></link>");
		 
		//load the jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//establish JDBC connection
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement","root","123456789");){
			PreparedStatement ps = con.prepareStatement(query);{
				ps.setInt(1, id);
				
				//resultset
				ResultSet rs = ps.executeQuery();
				if(rs.next()) {
				
				pw.println("<div style ='margin:auto;width:800px;margin-top:100px;'>");
				// Display success message if applicable
                if (success) {
                    pw.println("<div class='alert alert-success' role='alert'>");
                    pw.println("Record successfully updated!");
                    pw.println("</div>");
                }
				
				pw.println("<form action='edit?id="+id+"' method='post' onsubmit='return confirmEdit()'>");
				pw.println("<input type='hidden' name ='id' value='" +id+"'>");
				//pw.println("<a href='home.html'><button class='btn btn-outline-success'>Home</button></a>");
				//pw.println("<a href='showdata'><button class='btn btn-outline-success'>Show Users</button></a>");
				pw.println("<table class='table table-hover'>");
				
				pw.println("<tr>");
				pw.println("<td>Name</td>");
				pw.println("<td><input type='text' name='name' value='"+rs.getString("name")+"'></td>");
		        pw.println("</tr>");
                pw.println("<tr>");
				pw.println("<td>Email</td>");
				pw.println("<td><input type='email' name='email' value='"+rs.getString("email")+"'></td>");
		        pw.println("</tr>");
                pw.println("<tr>");
				pw.println("<td>Mobile</td>");
				pw.println("<td><input type='tel' name='mobile'  pattern='\\d{10}+' title='Please enter a valid mobile number (digits only)'  value='"+rs.getString("mobile")+"'></td>");
		        pw.println("</tr>");
                pw.println("<tr>");
				pw.println("<td>Dob</td>");
				pw.println("<td><input type='date' name='dob' value='"+rs.getString("dob")+"'></td>");
		        pw.println("</tr>");
                pw.println("<tr>");
				pw.println("<td>city</td>");
				pw.println("<td><input type='text' name='city' value='"+rs.getString("city")+"'></td>");
				
		        pw.println("</tr>");
                pw.println("<tr>");
				pw.println("<td>gender</td>");
				pw.println("<td><input type='radio' name='gender' value='male'"+rs.getString("gender")+"'>Male &nbsp; <input type='radio' name='gender' value='female'"+rs.getString("gender")+"'>Female</td>");
		        pw.println("</tr>");
		        pw.println("<tr>");
		        pw.println("<td>Password</td>");
		        pw.println("<td><input type='password' name='password' value='"+rs.getString("password")+"'></td>"); 
		        pw.println("</tr>");
		        pw.println("<tr>");
				pw.println("<td><button type='submit' class='btn btn-outline-success'>Edit</button></td>");
				
				
		        pw.println("</tr>");
				pw.println("</table>");
				pw.println("</form>");
				pw.println("</div>");
				}else {
					pw.println("<h2>No user found with ID: " + id + "</h2>");
				}
				
			}	
			
		} catch (SQLException se) {
			pw.println("<h2>"+se.getMessage()+"</h2>");
			se.printStackTrace();		
			}catch(Exception e) {
				e.printStackTrace();
			}
		//pw.println("<a href='home.html'<<button class='btn btn-outline-success'>Home</button></a>");
		
		
	    pw.println("</body>");
	    pw.println("</html>");
		
		 
	    pw.close();
}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}
	

