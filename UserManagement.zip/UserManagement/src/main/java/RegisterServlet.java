import java.io.IOException;



import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {

	private final static String query ="insert into user(name,email,mobile,dob,city,gender,password) values(?,?,?,?,?,?,?)";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//get PrinterWriter
		PrintWriter pw = res.getWriter();
		//set content type
		res.setContentType("text/html");
		//get the values
		String name = req.getParameter("userName");
		String email = req.getParameter("email");
		String mobile = req.getParameter("mobile");
		String dob = req.getParameter("dob");
		String city =req.getParameter("city");
		String gender = req.getParameter("gender");
		String password = req.getParameter("password");

		
		// Validation
        boolean valid = true;
        StringBuilder errors = new StringBuilder();

        // Validate Email
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher = emailPattern.matcher(email);
        if (!emailMatcher.matches()) {
            valid = false;
            errors.append("<p>Invalid email format.</p>");
        }
        // Validate Mobile Number
        String mobileRegex = "\\d{10}";
        Pattern mobilePattern = Pattern.compile(mobileRegex);
        Matcher mobileMatcher = mobilePattern.matcher(mobile);
        if (!mobileMatcher.matches()) {
            valid = false;
            errors.append("<p>Mobile number must be exactly 10 digits.</p>");
        }

        // Validate Password
        if (password == null || password.isEmpty()) {
            valid = false;
            errors.append("<p>Password cannot be empty.</p>");
        }
		
        // Hash the Password
      //  String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
        
		//load the jdbc driver
        if (valid) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
        }
		//establish JDBC connection
        if (valid) {
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement","root","123456789");){
			PreparedStatement ps = con.prepareStatement(query);{
				ps.setString(1, name);
				ps.setString(2, email);
				ps.setString(3, mobile);
				ps.setString(4, dob);
				ps.setString(5, city);
				ps.setString(6, gender);
			    ps.setString(7, password);
				int count = ps.executeUpdate();
				if(count==1) {
					 pw.println("<html><body>");
					pw.println("<h2> Successfully Registered</h2>");
					pw.println("<a href='home.html'><button class='btn btn-outline-success'>Home</button></a>");
                    pw.println("<a href='showdata'><button class='btn btn-outline-success'>Show Users</button></a>");
                    pw.println("</body></html>");
				}else {
					pw.println("<html><body>");
					pw.println("<h2> Unsuccessful Register</h2>");
                    pw.println("</body></html>");
	
					}
				}
				
			
		} catch (SQLException se) {
			pw.println("<html><body>");
			pw.println("<h2>"+se.getMessage()+"</h2>");
			 pw.println("</body></html>");
			se.printStackTrace();		
			}catch(Exception e) {
				e.printStackTrace();
			}
        }else {
        	// Display validation errors
        	pw.println("<html><body>");
            pw.println("<h2>Registration Failed</h2>");
            pw.println(errors.toString());
            pw.println("<a href='home.html'<<button class='btn btn-outline-success'>Home</button></a>");
            pw.println("<a href='showdata'<<button class='btn btn-outline-success'>Show users</button></a>");
            pw.println("</body></html>");
         
        }
		pw.close();
}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}
