import java.io.IOException;


import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/edit")
public class EditrecordServlet extends HttpServlet {

	
	private final static String query ="update user set name=?,email=?,mobile=?,dob=?,city=?,gender=? where id =?";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//get PrinterWriter
		PrintWriter pw = res.getWriter();
		//set content type
		res.setContentType("text/html");
		int id = Integer.parseInt(req.getParameter("id"));
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		String mobile = req.getParameter("mobile");
		String dob = req.getParameter("dob");
		String city = req.getParameter("city");
		String gender = req.getParameter("gender");
		String password = req.getParameter("password");
		
		// Validate mobile number
	    if (mobile == null || !mobile.matches("\\d+")) {
	        pw.println("<h2>Invalid mobile number. Please enter only digits.</h2>");
	        pw.println("<a href='editurl?id=" + id + "'><button class='btn btn-outline-success'>Back</button></a>");
	        pw.close();
	        return;
	    }
		
		//load the jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//establish JDBC connection
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement","root","123456789");){
			PreparedStatement ps = con.prepareStatement(query);{
				ps.setString(1,name);
				ps.setString(2,email);
				ps.setString(3,mobile);
				ps.setString(4,dob);
				ps.setString(5,city);
				ps.setString(6,gender);
				ps.setInt(7, id);
				if (password != null && !password.isEmpty()) {
	                ps.setString(7, password);
	                ps.setInt(8, id);
	            } else {
	                ps.setInt(7, id);
	            }
				int count = ps.executeUpdate();
				if(count==1) {
					res.sendRedirect("editurl?id=" + id + "&success=true");
					//pw.println("<h2> Successfully edited Record</h2>");
				}else {
					pw.println("<h2> Unsuccessful edit</h2>");
						
					}
				}
				
			
		} catch (SQLException se) {
			pw.println("<h2>"+se.getMessage()+"</h2>");
			se.printStackTrace();		
			}catch(Exception e) {
				e.printStackTrace();
			}
		pw.println("<a href='home.html'<<button class='btn btn-outline-success'>Home</button></a>"); 
		pw.println("&nbsp; &nbsp;");
		pw.println("<a href='showdata'<<button class='btn btn-outline-success'>Show Users</button></a>");
		pw.close();
}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}
