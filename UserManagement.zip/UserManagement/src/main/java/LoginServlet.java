

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	
       
	private final static String query = "SELECT id, name, email,profile_pic FROM user WHERE name = ? AND email = ?";
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		 // Set the content type
        res.setContentType("text/html");

        // Get PrintWriter
        PrintWriter pw = res.getWriter();

        // Retrieve form parameters
        String userName = req.getParameter("userName");
        String email = req.getParameter("email");

        // Load the JDBC driver and establish a connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement", "root", "123456789")) {
                // Prepare the SQL statement
                PreparedStatement ps = con.prepareStatement(query);
                ps.setString(1, userName);
                ps.setString(2, email);

                // Execute the query
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    // User is found
                    int userId = rs.getInt("id");
                    String profilePic = rs.getString("profile_pic");
                    if (profilePic == null || profilePic.isEmpty()) {
                        profilePic = "user1.jfif"; // default profile picture
                    }
                    pw.println("<html><body>");
                    pw.println("<h2>Welcome, " + userName + "!</h2>");
                    pw.println("<img src='images/profile_pics/" + profilePic + "' alt='Profile Picture' style='width:50px;height:50px;' />");
                    pw.println("<p>Your email: " + email + "</p>");
                    pw.println("<a href='showdata'>Show Users</a>");
                    pw.println("</body></html>");
                } else {
                    // User not found
                    pw.println("<html><body>");
                    pw.println("<h2>Login Failed</h2>");
                    pw.println("<p>Invalid username or email.</p>");
                    pw.println("<a href='login.jsp'>Try Again</a>");
                    pw.println("</body></html>");
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            pw.println("<html><body>");
            pw.println("<h2>Error occurred</h2>");
            pw.println("<p>" + e.getMessage() + "</p>");
            pw.println("</body></html>");
        }

        // Close the PrintWriter
        pw.close();
	}
}