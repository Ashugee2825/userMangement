import java.io.IOException;



import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/showdata")
public class ShowUserServlet extends HttpServlet {

	private final static String query ="select id,name,email,mobile,dob,city,gender from user";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//get PrinterWriter
		PrintWriter pw = res.getWriter();
		//set content type
		res.setContentType("text/html");
		
		

		pw.println("<link rel='stylesheet' href ='css/bootstrap.css'></link>");
		 
		//load the jdbc driver
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (Exception e) {
			e.printStackTrace();
		}
		//establish JDBC connection
		try(Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/usermanagement","root","123456789");){
			PreparedStatement ps = con.prepareStatement(query);{
				//resultset
				ResultSet rs = ps.executeQuery();
				
				pw.println("<!DOCTYPE html>");
	            pw.println("<html>");
	            pw.println("<head>");
	            pw.println("<meta charset='UTF-8'>");
	            pw.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
	            pw.println("<title>User Data</title>");
	            pw.println("<link rel='stylesheet' href='https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css'>");
	            pw.println("<link rel='stylesheet' href='css/bootstrap.css'>");
	            pw.println("<script src='https://code.jquery.com/jquery-3.6.0.min.js'></script>");
	            pw.println("<script src='https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js'></script>");
	            pw.println("</head>");
	            pw.println("<body>");
				pw.println("<div style ='margin:auto;width:800px;margin-top:100px;'>");
				pw.println("<a href='home.html'><button class='btn btn-outline-success'>Home</button></a>");
				
				pw.println("<table id ='userTable' class='table table-hover table-striped'>");
				pw.println("<thead>");
				pw.println("<tr>");
				pw.println("<th>ID</th>");
				pw.println("<th>Name</th>");
				pw.println("<th>Email</th>");
				pw.println("<th>Mobile</th>");
				pw.println("<th>DOB</th>");
				pw.println("<th>City</th>");
				pw.println("<th>Gender</th>");
				
				pw.println("<th>Edit</th>");
				pw.println("<th>Delete</th>");
				
				
				pw.println("</tr>");
				pw.println("</thead>");
				pw.println("<tbody>");
				while(rs.next()) {
					pw.println("<tr>");
					pw.println("<td>"+rs.getInt("id")+"</td>");
					pw.println("<td>"+rs.getString("name")+"</td>");
					pw.println("<td>"+rs.getString("email")+"</td>");
					pw.println("<td>"+rs.getString("mobile")+"</td>");
					pw.println("<td>"+rs.getString("dob")+"</td>");
					pw.println("<td>"+rs.getString("city")+"</td>");
					pw.println("<td>"+rs.getString("gender")+"</td>");
					
					pw.println("<td><a href='editurl?id="+rs.getInt("id")+"'>Edit</a></td>");
					pw.println("<td><a href='deleteurl?id="+rs.getInt("id")+"'>Delete</a></td>");
					pw.println("</tr>");
				}
				pw.println("</tbody>");
				pw.println("</table>");
				 
				//pw.println("<a href='home.html'><button class='btn btn-outline-success'>Home</button></a>");
				pw.println("</div>");
				 pw.println("<script>");
		            pw.println("$(document).ready(function() {");
		            pw.println("    $('#userTable').DataTable();");
		            pw.println("});");
		            pw.println("</script>");
		            
		            pw.println("</body>");
		            pw.println("</html>");  
				
			}	
			
		} catch (SQLException se) {
			pw.println("<h2>"+se.getMessage()+"</h2>");
			se.printStackTrace();		
			}catch(Exception e) {
				e.printStackTrace();
			}
		
		pw.close();
}
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req,res);
	}
}
